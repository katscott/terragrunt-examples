const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");

const routes = require("./routes");

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.use('/api', routes);

app.use(function(req, res, next) {
    res.status(404);
    res.send('404: File Not Found');
});

module.exports = app;