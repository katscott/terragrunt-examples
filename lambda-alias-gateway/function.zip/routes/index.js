var router = require('express').Router();

router.use('/hello', require('./hello')); 

module.exports = router;