var router = require('express').Router();
var generateGreetings = require('./generateGreetings');

router.get('/', function(req, res, next) {  
    res.send({
        message: generateGreetings()
    });
});

module.exports = router;  