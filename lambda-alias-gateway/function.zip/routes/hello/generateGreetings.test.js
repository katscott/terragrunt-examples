const generateGreetings = require('./generateGreetings');

describe("generateGreetings", () => {
    it("returns Greetings!", () => {
        expect(generateGreetings()).toBe("Greetings!");
    });
});