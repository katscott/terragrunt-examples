function generateGreetings() {
    return "Greetings!";
}

module.exports = generateGreetings;